from django.contrib import admin
from .models import TeacherProfile, Session, Payment

@admin.register(TeacherProfile)
class TeacherProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'subject', 'hourly_rate', 'is_verified']
    list_filter = ['is_verified', 'subject']

@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ['subject', 'teacher', 'student', 'scheduled_time', 'price', 'status']
    list_filter = ['status', 'subject']

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['session', 'amount', 'status', 'created_at']