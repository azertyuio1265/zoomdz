from rest_framework import viewsets, status, generics
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.shortcuts import get_object_or_404
from .models import TeacherProfile, Session
from .serializers import TeacherProfileSerializer, SessionSerializer, CreateSessionSerializer
import uuid

class TeacherProfileViewSet(viewsets.ModelViewSet):
    queryset = TeacherProfile.objects.all()
    serializer_class = TeacherProfileSerializer
    
    def get_permissions(self):
        if self.action == 'list' or self.action == 'retrieve':
            return [AllowAny()]
        return [IsAuthenticated()]

class SessionViewSet(viewsets.ModelViewSet):
    queryset = Session.objects.all()
    serializer_class = SessionSerializer
    
    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [AllowAny()]
        return [IsAuthenticated()]
    
    def perform_create(self, serializer):
        serializer.save()

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def initiate_payment(request, session_id):
    """بدء عملية الدفع عبر شارجيلي"""
    session = get_object_or_404(Session, id=session_id)
    
    # هنا ستدمج شارجيلي
    # سنضيف الكود الكامل لاحقاً
    
    return Response({
        'payment_url': 'https://checkout.chargily.dz/pay/123',
        'session_id': str(session.id)
    }, status=status.HTTP_200_OK)

@api_view(['POST'])
def payment_webhook(request):
    """استقبال تأكيد الدفع من شارجيلي"""
    # معالجة الـ webhook من شارجيلي
    return Response({'status': 'ok'})