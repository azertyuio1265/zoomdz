from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'teachers', views.TeacherProfileViewSet)
router.register(r'sessions', views.SessionViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('initiate-payment/<uuid:session_id>/', views.initiate_payment, name='initiate-payment'),
    path('webhook/chargily/', views.payment_webhook, name='payment-webhook'),
]