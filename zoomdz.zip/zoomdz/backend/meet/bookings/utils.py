import hashlib
import hmac
import json
from django.conf import settings
from django.core.cache import cache
import requests

def generate_room_token(room_name, user_id, user_name, is_teacher=False):
    """
    إنشاء رمز دخول لغرفة الفيديو
    """
    import jwt
    import time
    
    payload = {
        'sub': user_id,
        'name': user_name,
        'room': room_name,
        'can_publish': is_teacher,  # الأستاذ فقط ينشر الفيديو
        'can_subscribe': True,
        'exp': int(time.time()) + 3600 * 24  # صلاحية 24 ساعة
    }
    
    token = jwt.encode(payload, settings.SECRET_KEY, algorithm='HS256')
    return token

def verify_chargily_signature(payload, signature):
    """
    التحقق من توقيع webhook من شارجيلي
    """
    secret = settings.CHARGILY_SECRET_KEY
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        json.dumps(payload).encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(expected_signature, signature)

def create_chargily_payment(amount, success_url, failure_url, description, client_name, client_email):
    """
    إنشاء طلب دفع عبر شارجيلي
    """
    api_key = settings.CHARGILY_API_KEY
    mode = settings.CHARGILY_MODE
    
    url = 'https://api.chargily.dz/payments'
    if mode == 'test':
        url = 'https://sandbox.chargily.dz/payments'
    
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'amount': float(amount),
        'currency': 'dzd',
        'success_url': success_url,
        'failure_url': failure_url,
        'description': description,
        'client_name': client_name,
        'client_email': client_email
    }
    
    response = requests.post(url, json=data, headers=headers)
    return response.json()

def get_teacher_sessions_cache(teacher_id):
    """
    جلب حصص الأستاذ من الكاش
    """
    cache_key = f'teacher_sessions_{teacher_id}'
    sessions = cache.get(cache_key)
    
    if sessions is None:
        from .models import Session
        sessions = Session.objects.filter(teacher_id=teacher_id, status='pending')
        cache.set(cache_key, sessions, 300)  # تخزين لمدة 5 دقائق
    
    return sessions

def clear_teacher_cache(teacher_id):
    """
    مسح كاش الأستاذ عند التحديث
    """
    cache_key = f'teacher_sessions_{teacher_id}'
    cache.delete(cache_key)