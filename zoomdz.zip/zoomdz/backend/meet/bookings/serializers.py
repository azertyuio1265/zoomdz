from rest_framework import serializers
from .models import TeacherProfile, Session, Payment
from django.contrib.auth.models import User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']

class TeacherProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = TeacherProfile
        fields = '__all__'

class SessionSerializer(serializers.ModelSerializer):
    teacher_details = TeacherProfileSerializer(source='teacher', read_only=True)
    student_details = UserSerializer(source='student', read_only=True)
    
    class Meta:
        model = Session
        fields = '__all__'
        read_only_fields = ['id', 'room_name', 'created_at']

class CreateSessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Session
        fields = ['teacher', 'subject', 'scheduled_time', 'duration_minutes', 'price']