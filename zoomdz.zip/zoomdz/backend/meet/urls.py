from django.contrib import admin
from django.urls import path, include
from django.http import JsonResponse

def health_check(request):
    """نقطة نهاية للتحقق من صحة الخدمة"""
    return JsonResponse({
        'status': 'ok',
        'message': 'الخدمة تعمل بشكل طبيعي'
    })

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('bookings.urls')),
    path('health/', health_check, name='health'),
]