import React, { useState, useEffect } from 'react'
import axios from 'axios'

function Dashboard() {
  const [teachers, setTeachers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchTeachers()
  }, [])

  const fetchTeachers = async () => {
    try {
      const response = await axios.get('/api/teachers/')
      setTeachers(response.data)
    } catch (error) {
      console.error('Error fetching teachers:', error)
    } finally {
      setLoading(false)
    }
  }

  const bookSession = async (teacherId) => {
    // هنا سنضيف منطق الحجز لاحقاً
    alert('سيتم إضافة وظيفة الحجز قريباً')
  }

  if (loading) {
    return <div style={styles.loading}>جاري التحميل...</div>
  }

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1>منصة الدروس الخصوصية الجزائرية</h1>
        <p>اختر أستاذك وابدأ التعلم</p>
      </header>
      
      <div style={styles.teachersGrid}>
        {teachers.map(teacher => (
          <div key={teacher.id} style={styles.teacherCard}>
            <img 
              src={teacher.profile_image || '/default-avatar.png'} 
              alt={teacher.user.username}
              style={styles.avatar}
            />
            <h3>الأستاذ: {teacher.user.first_name || teacher.user.username}</h3>
            <p><strong>المادة:</strong> {teacher.subject}</p>
            <p><strong>السعر:</strong> {teacher.hourly_rate} دج/ساعة</p>
            <p><strong>نبذة:</strong> {teacher.bio.substring(0, 100)}...</p>
            <button onClick={() => bookSession(teacher.id)} style={styles.bookButton}>
              احجز حصة الآن
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

const styles = {
  container: {
    fontFamily: 'Tahoma, Arial, sans-serif',
    background: '#f0f2f5',
    minHeight: '100vh'
  },
  header: {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    color: 'white',
    padding: '40px 20px',
    textAlign: 'center'
  },
  teachersGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: '20px',
    padding: '40px',
    maxWidth: '1200px',
    margin: '0 auto'
  },
  teacherCard: {
    background: 'white',
    borderRadius: '15px',
    padding: '20px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
    textAlign: 'center'
  },
  avatar: {
    width: '100px',
    height: '100px',
    borderRadius: '50%',
    objectFit: 'cover',
    marginBottom: '15px'
  },
  bookButton: {
    background: '#667eea',
    color: 'white',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '16px',
    marginTop: '15px'
  },
  loading: {
    textAlign: 'center',
    padding: '50px',
    fontSize: '20px'
  }
}

export default Dashboard