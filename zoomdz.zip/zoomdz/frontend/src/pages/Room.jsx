import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { LiveKitRoom, VideoConference } from '@livekit/components-react'
import '@livekit/components-styles'

function Room() {
  const { roomName } = useParams()
  const [token, setToken] = useState(null)
  const [wsUrl, setWsUrl] = useState(null)

  useEffect(() => {
    // جلب رمز الدخول من الخادم
    const fetchToken = async () => {
      try {
        const response = await fetch(`/api/rooms/${roomName}/token`)
        const data = await response.json()
        setToken(data.token)
        setWsUrl(data.wsUrl)
      } catch (error) {
        console.error('Error fetching token:', error)
      }
    }
    
    fetchToken()
  }, [roomName])

  if (!token || !wsUrl) {
    return <div style={styles.loading}>جاري تحضير الغرفة...</div>
  }

  return (
    <div style={styles.container}>
      <LiveKitRoom
        serverUrl={wsUrl}
        token={token}
        connect={true}
        video={true}
        audio={true}
      >
        <VideoConference />
      </LiveKitRoom>
    </div>
  )
}

const styles = {
  container: {
    height: '100vh',
    width: '100vw',
    margin: 0,
    padding: 0
  },
  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    fontSize: '20px',
    fontFamily: 'Tahoma, Arial, sans-serif'
  }
}

export default Room