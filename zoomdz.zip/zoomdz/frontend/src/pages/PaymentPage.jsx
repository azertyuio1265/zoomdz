import React, { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'

function PaymentPage() {
  const { sessionId } = useParams()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)

  const handlePayment = async () => {
    setLoading(true)
    try {
      const token = localStorage.getItem('token')
      const response = await axios.post(
        `/api/initiate-payment/${sessionId}/`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      )
      
      // التوجيه إلى صفحة دفع شارجيلي
      window.location.href = response.data.payment_url
    } catch (error) {
      console.error('Payment error:', error)
      alert('حدث خطأ في عملية الدفع، حاول مرة أخرى')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>تأكيد الحجز والدفع</h1>
        <div style={styles.details}>
          <p><strong>المادة:</strong> الرياضيات</p>
          <p><strong>الأستاذ:</strong> أحمد بن علي</p>
          <p><strong>السعر:</strong> 1500 دج</p>
          <p><strong>المدة:</strong> 60 دقيقة</p>
        </div>
        <button 
          onClick={handlePayment} 
          disabled={loading}
          style={styles.button}
        >
          {loading ? 'جاري التحويل...' : 'ادفع الآن عبر شارجيلي'}
        </button>
        <p style={styles.note}>طرق الدعم المتاحة: EDAHABIA، CIB، CCP، Baridimob</p>
      </div>
    </div>
  )
}

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    fontFamily: 'Tahoma, Arial, sans-serif'
  },
  card: {
    background: 'white',
    borderRadius: '20px',
    padding: '40px',
    boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
    maxWidth: '500px',
    width: '90%',
    textAlign: 'center'
  },
  title: {
    color: '#333',
    marginBottom: '30px'
  },
  details: {
    textAlign: 'right',
    marginBottom: '30px',
    padding: '20px',
    background: '#f5f5f5',
    borderRadius: '10px'
  },
  button: {
    background: '#28a745',
    color: 'white',
    border: 'none',
    padding: '15px 30px',
    fontSize: '18px',
    borderRadius: '10px',
    cursor: 'pointer',
    width: '100%',
    marginBottom: '20px'
  },
  note: {
    fontSize: '12px',
    color: '#666',
    marginTop: '20px'
  }
}

export default PaymentPage