import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import PaymentPage from './pages/PaymentPage'
import Dashboard from './pages/Dashboard'
import Room from './pages/Room'

const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="app">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/payment/:sessionId" element={<PaymentPage />} />
            <Route path="/room/:roomName" element={<Room />} />
          </Routes>
        </div>
      </Router>
    </QueryClientProvider>
  )
}

export default App