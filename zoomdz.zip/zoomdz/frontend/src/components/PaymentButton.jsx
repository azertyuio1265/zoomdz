import React, { useState } from 'react'
import axios from 'axios'

function PaymentButton({ sessionId, amount, onSuccess, onError }) {
  const [loading, setLoading] = useState(false)

  const handlePayment = async () => {
    setLoading(true)
    try {
      const token = localStorage.getItem('access_token')
      
      const response = await axios.post(
        `/api/initiate-payment/${sessionId}/`,
        {},
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      )

      if (response.data.payment_url) {
        // توجيه المستخدم إلى صفحة دفع شارجيلي
        window.location.href = response.data.payment_url
      }
      
      if (onSuccess) {
        onSuccess(response.data)
      }
    } catch (error) {
      console.error('Payment error:', error)
      
      let errorMessage = 'حدث خطأ في عملية الدفع'
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message
      }
      
      if (onError) {
        onError(errorMessage)
      } else {
        alert(errorMessage)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <button
      onClick={handlePayment}
      disabled={loading}
      style={{
        backgroundColor: loading ? '#ccc' : '#28a745',
        color: 'white',
        border: 'none',
        padding: '12px 24px',
        fontSize: '16px',
        borderRadius: '8px',
        cursor: loading ? 'not-allowed' : 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '10px',
        width: '100%'
      }}
    >
      {loading ? (
        <>
          <span className="spinner"></span>
          جاري التحويل...
        </>
      ) : (
        <>
          💳 دفع {amount} دج عبر شارجيلي
        </>
      )}
    </button>
  )
}

// إضافة الـ CSS للـ spinner
const style = document.createElement('style')
style.textContent = `
  .spinner {
    width: 18px;
    height: 18px;
    border: 2px solid white;
    border-top: 2px solid transparent;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`
document.head.appendChild(style)

export default PaymentButton